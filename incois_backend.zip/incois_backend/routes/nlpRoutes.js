const express = require('express');
const db = require('../config/db');
const { protect, authorize } = require('../middleware/authMiddleware');

const router = express.Router();

// Get NLP-processed trends and insights.
// This data would be periodically populated by your NLP microservice.
router.get('/trends', protect, authorize('analyst', 'admin'), async (req, res) => {
  try {
    const trends = await db.query('SELECT * FROM social_media_hotspots ORDER BY created_at DESC');
    res.json(trends.rows);
  } catch (err) {
    console.error(err);
    res.status(500).send('Server error');
  }
});

module.exports = router;





auth middle ware

const jwt = require('jsonwebtoken');
const db = require('../config/db');

exports.protect = async (req, res, next) => {
  let token;

  if (req.headers.authorization && req.headers.authorization.startsWith('Bearer')) {
    token = req.headers.authorization.split(' ')[1];
  }

  if (!token) {
    return res.status(401).json({ msg: 'Not authorized, no token' });
  }

  try {
    const decoded = jwt.verify(token, process.env.JWT_SECRET);
    const userResult = await db.query('SELECT id, role FROM users WHERE id = $1', [decoded.id]);
    
    if (userResult.rows.length === 0) {
      return res.status(401).json({ msg: 'Not authorized, user not found' });
    }
    
    req.user = userResult.rows[0];
    next();
  } catch (err) {
    console.error(err);
    res.status(401).json({ msg: 'Not authorized, token failed' });
  }
};

exports.authorize = (...roles) => {
  return (req, res, next) => {
    if (!roles.includes(req.user.role)) {
      return res.status(403).json({ msg: `User role ${req.user.role} is not authorized` });
    }
    next();
  };
};


utils/fileUpload.js

const multer = require('multer');

// Simple disk storage configuration.
const storage = multer.diskStorage({
  destination: function (req, file, cb) {
    cb(null, './uploads/');
  },
  filename: function (req, file, cb) {
    cb(null, file.fieldname + '-' + Date.now() + '.jpg');
  }
});

exports.upload = multer({ storage: storage });

utils/validator.js

const validator = require('validator');

exports.validateRegistration = (data) => {
  const errors = {};

  if (!data.email || !validator.isEmail(data.email)) {
    errors.email = 'Please provide a valid email address';
  }
  if (!data.password || data.password.length < 6) {
    errors.password = 'Password must be at least 6 characters';
  }
  if (!data.username || data.username.length < 3) {
    errors.username = 'Username must be at least 3 characters';
  }

  return {
    errors,
    isValid: Object.keys(errors).length === 0
  };
};
