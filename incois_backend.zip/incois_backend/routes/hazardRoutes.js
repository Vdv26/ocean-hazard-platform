const express = require('express');
const { submitReport, getReports, getVerifiedReports, verifyReport } = require('../controllers/hazardController');
const { protect, authorize } = require('../middleware/authMiddleware');
const multer = require('multer');

// Configure multer for file uploads
const upload = multer({ dest: 'uploads/' });

const router = express.Router();

// A protected route for citizens to submit reports with media files
router.post('/', protect, upload.array('media', 5), submitReport); 

// A protected route for analysts/admins to view all reports
router.get('/', protect, authorize('analyst', 'admin'), getReports);

// A protected route for all users to view verified reports on the public dashboard
router.get('/verified', protect, getVerifiedReports);

// A protected route for admins/analysts to verify a report
router.put('/:id/verify', protect, authorize('analyst', 'admin'), verifyReport);

module.exports = router;

