const express = require('express');
const { register, login } = require('../controllers/authController');

const router = express.Router();

router.post('/register', register); // Path for new users to sign up
router.post('/login', login);       // Path for existing users to log in

module.exports = router;