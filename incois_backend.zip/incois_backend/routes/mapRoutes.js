const express = require('express');
const db = require('../config/db');
const { protect, authorize } = require('../middleware/authMiddleware');

const router = express.Router();

// Get all verified hazard reports to display on the public dashboard map.
router.get('/reports', protect, async (req, res) => {
  try {
    const reports = await db.query('SELECT * FROM hazard_reports WHERE is_verified = TRUE');
    res.json(reports.rows);
  } catch (err) {
    console.error(err);
    res.status(500).send('Server error');
  }
});

// Get social media hotspots based on processed data.
router.get('/hotspots', protect, async (req, res) => {
  try {
    const hotspots = await db.query('SELECT * FROM social_media_hotspots');
    res.json(hotspots.rows);
  } catch (err) {
    console.error(err);
    res.status(500).send('Server error');
  }
});

module.exports = router;


alert routes

const express = require('express');
const db = require('../config/db');
const { protect, authorize } = require('../middleware/authMiddleware');

const router = express.Router();

// Route for admins to create a new alert
router.post('/', protect, authorize('admin'), async (req, res) => {
  const { title, description, severity, location } = req.body;
  try {
    const result = await db.query(
      'INSERT INTO alerts (title, description, severity, location) VALUES ($1, $2, $3, $4) RETURNING *',
      [title, description, severity, location]
    );
    res.status(201).json({ msg: 'Alert created successfully', alert: result.rows[0] });
  } catch (err) {
    console.error(err);
    res.status(500).send('Server error');
  }
});

// Route for anyone (authenticated) to get all alerts
router.get('/', protect, async (req, res) => {
  try {
    const alerts = await db.query('SELECT * FROM alerts ORDER BY created_at DESC');
    res.json(alerts.rows);
  } catch (err) {
    console.error(err);
    res.status(500).send('Server error');
  }
});

module.exports = router;

