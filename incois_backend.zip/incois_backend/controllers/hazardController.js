const db = require('../config/db');

exports.submitReport = async (req, res) => {
  const { report_type, description, latitude, longitude } = req.body;
  const media_url = req.files ? req.files.map(file => `/uploads/${file.filename}`) : [];

  try {
    const newReport = await db.query(
      'INSERT INTO hazard_reports (user_id, report_type, description, latitude, longitude, media_url) VALUES ($1, $2, $3, $4, $5, $6) RETURNING *',
      [req.user.id, report_type, description, latitude, longitude, media_url]
    );
    res.status(201).json({ msg: 'Report submitted successfully', report: newReport.rows[0] });
  } catch (err) {
    console.error(err);
    res.status(500).send('Server error');
  }
};

exports.getReports = async (req, res) => {
  try {
    const reports = await db.query('SELECT * FROM hazard_reports ORDER BY created_at DESC');
    res.json(reports.rows);
  } catch (err) {
    console.error(err);
    res.status(500).send('Server error');
  }
};

exports.getVerifiedReports = async (req, res) => {
  try {
    const reports = await db.query('SELECT * FROM hazard_reports WHERE is_verified = TRUE ORDER BY created_at DESC');
    res.json(reports.rows);
  } catch (err) {
    console.error(err);
    res.status(500).send('Server error');
  }
};

exports.verifyReport = async (req, res) => {
  const { id } = req.params;
  try {
    const result = await db.query('UPDATE hazard_reports SET is_verified = TRUE WHERE id = $1 RETURNING *', [id]);
    if (result.rows.length === 0) {
      return res.status(404).json({ msg: 'Report not found' });
    }
    res.json({ msg: 'Report verified successfully', report: result.rows[0] });
  } catch (err) {
    console.error(err);
    res.status(500).send('Server error');
  }
};
